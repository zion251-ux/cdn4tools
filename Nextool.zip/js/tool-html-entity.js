(function(){
  "use strict";
  var input = document.getElementById('he-input');
  var output = document.getElementById('he-output');

  function encode(str){
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
  function decode(str){
    var txt = document.createElement('textarea');
    txt.innerHTML = str;
    return txt.value;
  }

  document.getElementById('he-encode').addEventListener('click', function(){ output.value = encode(input.value); });
  document.getElementById('he-decode').addEventListener('click', function(){ output.value = decode(input.value); });
  document.getElementById('he-swap').addEventListener('click', function(){
    var tmp = input.value; input.value = output.value; output.value = tmp;
  });
  document.getElementById('he-clear').addEventListener('click', function(){ input.value=''; output.value=''; });
  document.getElementById('he-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to copy yet'); return; }
    window.NT.copyText(output.value, 'Copied to clipboard!');
  });
})();
