(function(){
  "use strict";
  var dropzone = document.getElementById('img-dropzone');
  var fileInput = document.getElementById('img-file-input');
  var previewWrap = document.getElementById('img-preview-wrap');
  var preview = document.getElementById('img-preview');
  var meta = document.getElementById('img-meta');
  var output = document.getElementById('img-output');
  var htmlOutput = document.getElementById('img-html-output');

  dropzone.addEventListener('click', function(){ fileInput.click(); });
  dropzone.addEventListener('dragover', function(e){ e.preventDefault(); dropzone.classList.add('dragover'); });
  dropzone.addEventListener('dragleave', function(){ dropzone.classList.remove('dragover'); });
  dropzone.addEventListener('drop', function(e){
    e.preventDefault(); dropzone.classList.remove('dragover');
    if(e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', function(){
    if(fileInput.files.length) handleFile(fileInput.files[0]);
  });

  function formatSize(bytes){
    if(bytes < 1024) return bytes + ' B';
    if(bytes < 1024*1024) return (bytes/1024).toFixed(1) + ' KB';
    return (bytes/(1024*1024)).toFixed(2) + ' MB';
  }

  function handleFile(file){
    if(!file.type.startsWith('image/')){ window.NT.toast('Please choose an image file'); return; }
    if(file.size > 8 * 1024 * 1024){ window.NT.toast('Image too large — please choose under 8MB'); return; }
    var reader = new FileReader();
    reader.onload = function(e){
      var dataUrl = e.target.result;
      preview.src = dataUrl;
      previewWrap.style.display = 'block';
      meta.textContent = file.name + ' — ' + formatSize(file.size) + ' — ' + file.type;
      output.value = dataUrl;
      htmlOutput.value = '<img src="' + dataUrl.slice(0, 60) + '...[truncated for display]" alt="' + file.name + '">';
      htmlOutput.dataset.full = '<img src="' + dataUrl + '" alt="' + file.name + '">';
      window.NT.toast('Image converted to Base64');
    };
    reader.readAsDataURL(file);
  }

  document.getElementById('img-copy-b64').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Upload an image first'); return; }
    window.NT.copyText(output.value, 'Data URL copied!');
  });

  document.getElementById('img-copy-html').addEventListener('click', function(){
    var full = htmlOutput.dataset.full;
    if(!full){ window.NT.toast('Upload an image first'); return; }
    window.NT.copyText(full, 'HTML tag copied!');
  });
})();
