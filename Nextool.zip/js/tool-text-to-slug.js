(function(){
  "use strict";
  var input = document.getElementById('slug-input');
  var sep = document.getElementById('slug-separator');
  var caseSel = document.getElementById('slug-case');
  var output = document.getElementById('slug-output');

  function slugify(text, separator, upper){
    var slug = text.toString().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); // strip accents
    slug = slug.toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-_]/g, '')
      .replace(/[\s_-]+/g, separator)
      .replace(new RegExp('^\\' + separator + '+|\\' + separator + '+$','g'), '');
    return upper ? slug.toUpperCase() : slug;
  }

  function update(){
    var separator = sep.value;
    var upper = caseSel.value === 'upper';
    output.value = slugify(input.value, separator, upper);
  }

  input.addEventListener('input', update);
  sep.addEventListener('change', update);
  caseSel.addEventListener('change', update);
  document.getElementById('slug-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to copy yet'); return; }
    window.NT.copyText(output.value, 'Slug copied!');
  });

  update();
})();
