(function(){
  "use strict";
  var input = document.getElementById('wc-input');

  function fmtTime(seconds){
    if(seconds < 60) return Math.ceil(seconds) + ' sec';
    var min = Math.floor(seconds/60);
    var sec = Math.round(seconds%60);
    return min + ' min ' + (sec ? sec + ' sec' : '');
  }

  function update(){
    var text = input.value;
    var trimmed = text.trim();
    var words = trimmed ? trimmed.split(/\s+/).filter(Boolean) : [];
    var chars = text.length;
    var charsNoSpace = text.replace(/\s/g,'').length;
    var sentences = trimmed ? (trimmed.match(/[^.!?]+[.!?]*/g) || []).filter(function(s){return s.trim().length;}).length : 0;
    var paragraphs = trimmed ? trimmed.split(/\n\s*\n/).filter(function(p){return p.trim().length;}).length : 0;

    document.getElementById('wc-words').textContent = words.length;
    document.getElementById('wc-chars').textContent = chars;
    document.getElementById('wc-chars-nospace').textContent = charsNoSpace;
    document.getElementById('wc-sentences').textContent = sentences;
    document.getElementById('wc-paragraphs').textContent = paragraphs || (trimmed ? 1 : 0);
    document.getElementById('wc-reading').textContent = fmtTime((words.length/200)*60);
    document.getElementById('wc-speaking').textContent = fmtTime((words.length/130)*60);
  }

  input.addEventListener('input', update);
  document.getElementById('wc-clear').addEventListener('click', function(){ input.value=''; update(); });
  update();
})();
