(function(){
  "use strict";

  function randomInRange(min, max, decimal){
    var val = Math.random() * (max - min) + min;
    return decimal ? Math.round(val*100)/100 : Math.floor(val + (max - Math.floor(max) === 0 ? 1 : 0)) ;
  }

  function generateInt(min, max){
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  function generateDecimal(min, max){
    return Math.round((Math.random() * (max - min) + min) * 100) / 100;
  }

  function shuffle(arr){
    for(var i = arr.length -1; i>0; i--){
      var j = Math.floor(Math.random()*(i+1));
      var tmp = arr[i]; arr[i]=arr[j]; arr[j]=tmp;
    }
    return arr;
  }

  function generate(){
    var min = parseFloat(document.getElementById('rng-min').value);
    var max = parseFloat(document.getElementById('rng-max').value);
    var count = parseInt(document.getElementById('rng-count').value, 10);
    var type = document.getElementById('rng-type').value;
    var order = document.getElementById('rng-order').value;
    var unique = document.getElementById('rng-unique').checked;

    if(isNaN(min) || isNaN(max) || min >= max){ window.NT.toast('Minimum must be less than maximum'); return; }
    if(!count || count < 1){ window.NT.toast('Enter a valid count'); return; }

    if(unique && type === 'integer'){
      var rangeSize = Math.floor(max) - Math.ceil(min) + 1;
      if(count > rangeSize){
        window.NT.toast('Range too small for ' + count + ' unique integers');
        return;
      }
    }

    var results = [];
    var seen = {};
    var attempts = 0;
    var maxAttempts = count * 50 + 1000;

    while(results.length < count && attempts < maxAttempts){
      attempts++;
      var num = type === 'integer' ? generateInt(Math.ceil(min), Math.floor(max)) : generateDecimal(min, max);
      if(unique){
        if(seen[num]) continue;
        seen[num] = true;
      }
      results.push(num);
    }

    if(order === 'asc') results.sort(function(a,b){return a-b;});
    else if(order === 'desc') results.sort(function(a,b){return b-a;});
    else if(order === 'shuffle') shuffle(results);

    document.getElementById('rng-output').value = results.join(', ');
  }

  document.getElementById('rng-generate').addEventListener('click', generate);
  document.getElementById('rng-copy').addEventListener('click', function(){
    var val = document.getElementById('rng-output').value;
    if(!val){ window.NT.toast('Generate numbers first'); return; }
    window.NT.copyText(val, 'Copied to clipboard!');
  });

  generate();
})();
