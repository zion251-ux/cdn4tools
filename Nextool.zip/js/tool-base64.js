(function(){
  "use strict";
  var textMode = document.getElementById('b64-text-mode');
  var fileMode = document.getElementById('b64-file-mode');
  var tabText = document.getElementById('b64-tab-text');
  var tabFile = document.getElementById('b64-tab-file');

  tabText.addEventListener('click', function(){
    tabText.classList.add('active'); tabFile.classList.remove('active');
    textMode.style.display = ''; fileMode.style.display = 'none';
  });
  tabFile.addEventListener('click', function(){
    tabFile.classList.add('active'); tabText.classList.remove('active');
    fileMode.style.display = ''; textMode.style.display = 'none';
  });

  var input = document.getElementById('b64-input');
  var output = document.getElementById('b64-output');
  var status = document.getElementById('b64-status');

  function setStatus(msg, ok){ status.textContent = msg; status.style.color = ok ? 'var(--accent-ink)' : 'var(--danger)'; }

  function utf8ToB64(str){
    return btoa(unescape(encodeURIComponent(str)));
  }
  function b64ToUtf8(str){
    return decodeURIComponent(escape(atob(str)));
  }

  document.getElementById('b64-encode').addEventListener('click', function(){
    try{
      output.value = utf8ToB64(input.value);
      setStatus('✓ Encoded successfully.', true);
    }catch(e){ setStatus('Encoding failed: ' + e.message, false); }
  });

  document.getElementById('b64-decode').addEventListener('click', function(){
    try{
      output.value = b64ToUtf8(input.value.trim());
      setStatus('✓ Decoded successfully.', true);
    }catch(e){ setStatus('Invalid Base64 string — could not decode.', false); }
  });

  document.getElementById('b64-swap').addEventListener('click', function(){
    var tmp = input.value; input.value = output.value; output.value = tmp;
  });

  document.getElementById('b64-clear').addEventListener('click', function(){
    input.value=''; output.value=''; setStatus('', true);
  });

  document.getElementById('b64-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to copy yet'); return; }
    window.NT.copyText(output.value, 'Copied to clipboard!');
  });

  /* ---- File mode ---- */
  var dropzone = document.getElementById('b64-dropzone');
  var fileInput = document.getElementById('b64-file-input');
  var fileOutput = document.getElementById('b64-file-output');
  var preview = document.getElementById('b64-file-preview');

  dropzone.addEventListener('click', function(){ fileInput.click(); });
  dropzone.addEventListener('dragover', function(e){ e.preventDefault(); dropzone.classList.add('dragover'); });
  dropzone.addEventListener('dragleave', function(){ dropzone.classList.remove('dragover'); });
  dropzone.addEventListener('drop', function(e){
    e.preventDefault(); dropzone.classList.remove('dragover');
    if(e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', function(){
    if(fileInput.files.length) handleFile(fileInput.files[0]);
  });

  function handleFile(file){
    if(file.size > 6 * 1024 * 1024){
      window.NT.toast('File too large — please choose under 6MB');
      return;
    }
    var reader = new FileReader();
    reader.onload = function(e){
      fileOutput.value = e.target.result;
      preview.innerHTML = '';
      if(file.type.indexOf('image/') === 0){
        var img = document.createElement('img');
        img.src = e.target.result;
        img.style.maxWidth = '220px';
        img.style.borderRadius = '12px';
        img.style.marginTop = '12px';
        preview.appendChild(img);
      }
      window.NT.toast('File converted to Base64');
    };
    reader.readAsDataURL(file);
  }

  document.getElementById('b64-file-copy').addEventListener('click', function(){
    if(!fileOutput.value){ window.NT.toast('Upload a file first'); return; }
    window.NT.copyText(fileOutput.value, 'Data URL copied!');
  });
})();
