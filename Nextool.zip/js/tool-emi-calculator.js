(function(){
  "use strict";

  function fmtCurrency(n){
    return '$' + n.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2});
  }

  function calculate(){
    var P = parseFloat(document.getElementById('emi-principal').value);
    var annualRate = parseFloat(document.getElementById('emi-rate').value);
    var years = parseFloat(document.getElementById('emi-tenure').value);

    if(!P || !annualRate || !years || P <= 0 || years <= 0){
      window.NT.toast('Enter valid loan details');
      return;
    }

    var r = (annualRate/100)/12;
    var n = years * 12;
    var emi = P * r * Math.pow(1+r, n) / (Math.pow(1+r, n) - 1);
    var totalPayment = emi * n;
    var totalInterest = totalPayment - P;

    document.getElementById('emi-monthly').textContent = fmtCurrency(emi);
    document.getElementById('emi-total-interest').textContent = fmtCurrency(totalInterest);
    document.getElementById('emi-total-payment').textContent = fmtCurrency(totalPayment);

    buildSchedule(P, r, n, emi);
  }

  function buildSchedule(P, r, n, emi){
    var tbody = document.querySelector('#emi-schedule-table tbody');
    tbody.innerHTML = '';
    var balance = P;
    for(var month=1; month<=n; month++){
      var interestPortion = balance * r;
      var principalPortion = emi - interestPortion;
      balance -= principalPortion;
      if(balance < 0) balance = 0;
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>' + month + '</td><td>' + fmtCurrency(principalPortion) + '</td><td>' + fmtCurrency(interestPortion) + '</td><td>' + fmtCurrency(balance) + '</td>';
      tbody.appendChild(tr);
    }
  }

  document.getElementById('emi-calculate').addEventListener('click', calculate);
  document.querySelectorAll('#emi-principal, #emi-rate, #emi-tenure').forEach(function(inp){
    inp.addEventListener('input', calculate);
  });

  document.getElementById('emi-toggle-schedule').addEventListener('click', function(){
    var wrap = document.getElementById('emi-schedule-wrap');
    wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
  });

  calculate();
})();
