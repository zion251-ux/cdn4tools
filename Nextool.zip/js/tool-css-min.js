(function(){
  "use strict";
  var input = document.getElementById('css-input');
  var output = document.getElementById('css-output');
  var status = document.getElementById('css-status');

  function minify(css){
    return css
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/\s+/g, ' ')
      .replace(/\s*([{}:;,])\s*/g, '$1')
      .replace(/;}/g, '}')
      .trim();
  }

  function beautify(css){
    css = css.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\s+/g, ' ').trim();
    var result = '';
    var indent = 0;
    var i = 0;
    while(i < css.length){
      var ch = css[i];
      if(ch === '{'){
        result = result.trimEnd() + ' {\n';
        indent++;
        result += '  '.repeat(indent);
      } else if(ch === '}'){
        indent = Math.max(0, indent - 1);
        result = result.trimEnd() + '\n' + '  '.repeat(indent) + '}\n' + '  '.repeat(indent);
      } else if(ch === ';'){
        result += ';\n' + '  '.repeat(indent);
      } else {
        result += ch;
      }
      i++;
    }
    return result.split('\n').map(function(l){ return l.trimEnd(); }).filter(function(l,idx,arr){
      return !(l.trim()==='' && arr[idx-1] && arr[idx-1].trim()==='');
    }).join('\n').trim();
  }

  document.getElementById('css-minify').addEventListener('click', function(){
    if(!input.value.trim()){ status.textContent = 'Paste some CSS first.'; return; }
    output.value = minify(input.value);
    status.textContent = '✓ Minified — ' + input.value.length + ' → ' + output.value.length + ' characters.';
  });

  document.getElementById('css-beautify').addEventListener('click', function(){
    if(!input.value.trim()){ status.textContent = 'Paste some CSS first.'; return; }
    output.value = beautify(input.value);
    status.textContent = '✓ Beautified.';
  });

  document.getElementById('css-clear').addEventListener('click', function(){
    input.value=''; output.value=''; status.textContent='';
  });

  document.getElementById('css-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to copy yet'); return; }
    window.NT.copyText(output.value, 'Copied to clipboard!');
  });
})();
