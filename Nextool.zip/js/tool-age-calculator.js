(function(){
  "use strict";
  var dobInput = document.getElementById('age-dob');
  var asofInput = document.getElementById('age-asof');

  var ZODIAC = [
    {name:'Capricorn', start:[12,22], end:[1,19]},
    {name:'Aquarius', start:[1,20], end:[2,18]},
    {name:'Pisces', start:[2,19], end:[3,20]},
    {name:'Aries', start:[3,21], end:[4,19]},
    {name:'Taurus', start:[4,20], end:[5,20]},
    {name:'Gemini', start:[5,21], end:[6,20]},
    {name:'Cancer', start:[6,21], end:[7,22]},
    {name:'Leo', start:[7,23], end:[8,22]},
    {name:'Virgo', start:[8,23], end:[9,22]},
    {name:'Libra', start:[9,23], end:[10,22]},
    {name:'Scorpio', start:[10,23], end:[11,21]},
    {name:'Sagittarius', start:[11,22], end:[12,21]}
  ];

  function getZodiac(month, day){
    for(var i=0;i<ZODIAC.length;i++){
      var z = ZODIAC[i];
      var sM = z.start[0], sD = z.start[1], eM = z.end[0], eD = z.end[1];
      if(sM === eM){ if(month === sM && day >= sD && day <= eD) return z.name; }
      else {
        if((month === sM && day >= sD) || (month === eM && day <= eD)) return z.name;
      }
    }
    return 'Capricorn';
  }

  function calculate(){
    var dob = dobInput.value ? new Date(dobInput.value + 'T00:00:00') : null;
    var asof = asofInput.value ? new Date(asofInput.value + 'T00:00:00') : new Date();
    if(!dob || isNaN(dob.getTime())){
      window.NT.toast('Please select your date of birth');
      return;
    }
    if(dob > asof){
      window.NT.toast('Birth date must be before the reference date');
      return;
    }

    var years = asof.getFullYear() - dob.getFullYear();
    var months = asof.getMonth() - dob.getMonth();
    var days = asof.getDate() - dob.getDate();

    if(days < 0){
      months--;
      var prevMonth = new Date(asof.getFullYear(), asof.getMonth(), 0);
      days += prevMonth.getDate();
    }
    if(months < 0){
      years--;
      months += 12;
    }

    var totalDays = Math.floor((asof - dob) / (1000*60*60*24));

    var nextBirthday = new Date(asof.getFullYear(), dob.getMonth(), dob.getDate());
    if(nextBirthday < asof) nextBirthday.setFullYear(asof.getFullYear()+1);
    var daysToNext = Math.ceil((nextBirthday - asof) / (1000*60*60*24));

    document.getElementById('age-years').textContent = years;
    document.getElementById('age-months').textContent = months;
    document.getElementById('age-days').textContent = days;
    document.getElementById('age-total-days').textContent = totalDays.toLocaleString();
    document.getElementById('age-next-birthday').textContent = daysToNext;
    document.getElementById('age-zodiac').textContent = getZodiac(dob.getMonth()+1, dob.getDate());
  }

  document.getElementById('age-calculate').addEventListener('click', calculate);

  // Default to today for "as of" and auto-calc on dob change
  asofInput.valueAsDate = new Date();
  dobInput.addEventListener('change', calculate);
  asofInput.addEventListener('change', calculate);
})();
