(function(){
  "use strict";
  var input = document.getElementById('cc-input');
  var output = document.getElementById('cc-output');

  function words(str){
    return str.trim().split(/[\s_-]+/).filter(Boolean);
  }

  var converters = {
    upper: function(s){ return s.toUpperCase(); },
    lower: function(s){ return s.toLowerCase(); },
    title: function(s){
      return s.replace(/\w\S*/g, function(w){ return w.charAt(0).toUpperCase() + w.substr(1).toLowerCase(); });
    },
    sentence: function(s){
      var lower = s.toLowerCase();
      return lower.replace(/(^\s*\w|[.!?]\s*\w)/g, function(c){ return c.toUpperCase(); });
    },
    camel: function(s){
      var w = words(s.toLowerCase());
      return w.map(function(word, i){
        return i === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1);
      }).join('');
    },
    pascal: function(s){
      var w = words(s.toLowerCase());
      return w.map(function(word){ return word.charAt(0).toUpperCase() + word.slice(1); }).join('');
    },
    snake: function(s){ return words(s.toLowerCase()).join('_'); },
    kebab: function(s){ return words(s.toLowerCase()).join('-'); },
    alternating: function(s){
      var out = ''; var upper = false;
      for(var i=0;i<s.length;i++){
        var ch = s[i];
        if(/[a-zA-Z]/.test(ch)){ out += upper ? ch.toUpperCase() : ch.toLowerCase(); upper = !upper; }
        else out += ch;
      }
      return out;
    },
    inverse: function(s){
      return s.split('').map(function(ch){
        return ch === ch.toUpperCase() ? ch.toLowerCase() : ch.toUpperCase();
      }).join('');
    }
  };

  document.querySelectorAll('[data-case]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var type = btn.getAttribute('data-case');
      var fn = converters[type];
      if(fn) output.value = fn(input.value);
    });
  });

  document.getElementById('cc-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to copy yet'); return; }
    window.NT.copyText(output.value, 'Copied to clipboard!');
  });
  document.getElementById('cc-clear').addEventListener('click', function(){
    input.value=''; output.value='';
  });
})();
