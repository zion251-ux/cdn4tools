(function(){
  "use strict";
  var hexInput = document.getElementById('color-hex');
  var rgbInput = document.getElementById('color-rgb');
  var hslInput = document.getElementById('color-hsl');
  var picker = document.getElementById('color-picker');
  var swatch = document.getElementById('color-swatch');
  var cssOutput = document.getElementById('color-css-output');

  function hexToRgb(hex){
    hex = hex.replace('#','').trim();
    if(hex.length === 3) hex = hex.split('').map(function(c){return c+c;}).join('');
    if(!/^[0-9a-fA-F]{6}$/.test(hex)) return null;
    var num = parseInt(hex,16);
    return { r:(num>>16)&255, g:(num>>8)&255, b:num&255 };
  }
  function rgbToHex(r,g,b){
    return '#' + [r,g,b].map(function(x){ return x.toString(16).padStart(2,'0'); }).join('');
  }
  function rgbToHsl(r,g,b){
    r/=255; g/=255; b/=255;
    var max=Math.max(r,g,b), min=Math.min(r,g,b);
    var h,s,l=(max+min)/2;
    if(max===min){ h=s=0; }
    else{
      var d = max-min;
      s = l > 0.5 ? d/(2-max-min) : d/(max+min);
      switch(max){
        case r: h=(g-b)/d + (g<b?6:0); break;
        case g: h=(b-r)/d + 2; break;
        case b: h=(r-g)/d + 4; break;
      }
      h /= 6;
    }
    return { h: Math.round(h*360), s: Math.round(s*100), l: Math.round(l*100) };
  }
  function hslToRgb(h,s,l){
    h/=360; s/=100; l/=100;
    var r,g,b;
    if(s===0){ r=g=b=l; }
    else{
      var hue2rgb = function(p,q,t){
        if(t<0) t+=1; if(t>1) t-=1;
        if(t<1/6) return p+(q-p)*6*t;
        if(t<1/2) return q;
        if(t<2/3) return p+(q-p)*(2/3-t)*6;
        return p;
      };
      var q = l < 0.5 ? l*(1+s) : l+s-l*s;
      var p = 2*l-q;
      r = hue2rgb(p,q,h+1/3);
      g = hue2rgb(p,q,h);
      b = hue2rgb(p,q,h-1/3);
    }
    return { r: Math.round(r*255), g: Math.round(g*255), b: Math.round(b*255) };
  }

  function updateAll(source, r, g, b){
    var hex = rgbToHex(r,g,b);
    var hsl = rgbToHsl(r,g,b);
    if(source !== 'hex') hexInput.value = hex;
    if(source !== 'rgb') rgbInput.value = 'rgb(' + r + ', ' + g + ', ' + b + ')';
    if(source !== 'hsl') hslInput.value = 'hsl(' + hsl.h + ', ' + hsl.s + '%, ' + hsl.l + '%)';
    if(source !== 'picker') picker.value = hex;
    swatch.style.background = hex;
    cssOutput.textContent = 'background-color: ' + hex + ';\n/* or */\nbackground-color: rgb(' + r + ', ' + g + ', ' + b + ');\n/* or */\nbackground-color: hsl(' + hsl.h + ', ' + hsl.s + '%, ' + hsl.l + '%);';
  }

  hexInput.addEventListener('input', function(){
    var rgb = hexToRgb(hexInput.value);
    if(rgb) updateAll('hex', rgb.r, rgb.g, rgb.b);
  });

  rgbInput.addEventListener('input', function(){
    var m = rgbInput.value.match(/(\d+)\D+(\d+)\D+(\d+)/);
    if(m) updateAll('rgb', +m[1], +m[2], +m[3]);
  });

  hslInput.addEventListener('input', function(){
    var m = hslInput.value.match(/(\d+)\D+(\d+)%\D+(\d+)%/);
    if(m){
      var rgb = hslToRgb(+m[1], +m[2], +m[3]);
      updateAll('hsl', rgb.r, rgb.g, rgb.b);
    }
  });

  picker.addEventListener('input', function(){
    var rgb = hexToRgb(picker.value);
    if(rgb) updateAll('picker', rgb.r, rgb.g, rgb.b);
  });

  document.getElementById('color-copy-css').addEventListener('click', function(){
    window.NT.copyText(cssOutput.textContent, 'CSS copied!');
  });
})();
