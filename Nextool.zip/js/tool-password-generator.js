(function(){
  "use strict";
  var LOWER = 'abcdefghijklmnopqrstuvwxyz';
  var UPPER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  var NUMS  = '0123456789';
  var SYMS  = '!@#$%^&*()_+-=[]{}|;:,.<>?';
  var AMBIGUOUS = 'l1IO0';

  var lenInput = document.getElementById('pw-length');
  var lenVal = document.getElementById('pw-length-val');
  var output = document.getElementById('pw-output');
  var bar = document.getElementById('pw-strength-bar');
  var label = document.getElementById('pw-strength-label');

  function secureRandomInt(max){
    if(window.crypto && window.crypto.getRandomValues){
      var arr = new Uint32Array(1);
      window.crypto.getRandomValues(arr);
      return arr[0] % max;
    }
    return Math.floor(Math.random() * max);
  }

  function buildCharset(){
    var set = '';
    if(document.getElementById('pw-upper').checked) set += UPPER;
    if(document.getElementById('pw-lower').checked) set += LOWER;
    if(document.getElementById('pw-numbers').checked) set += NUMS;
    if(document.getElementById('pw-symbols').checked) set += SYMS;
    if(document.getElementById('pw-exclude-ambiguous').checked){
      set = set.split('').filter(function(c){ return AMBIGUOUS.indexOf(c) === -1; }).join('');
    }
    return set;
  }

  function generatePassword(length){
    var set = buildCharset();
    if(!set) return '';
    var pw = '';
    for(var i=0;i<length;i++){
      pw += set.charAt(secureRandomInt(set.length));
    }
    return pw;
  }

  function scorePassword(pw){
    var score = 0;
    if(pw.length >= 8) score++;
    if(pw.length >= 12) score++;
    if(pw.length >= 16) score++;
    if(/[A-Z]/.test(pw)) score++;
    if(/[0-9]/.test(pw)) score++;
    if(/[^A-Za-z0-9]/.test(pw)) score++;
    return score; // 0-6
  }

  function updateStrength(pw){
    var score = scorePassword(pw);
    var pct = Math.min(100, (score/6)*100);
    var color, text;
    if(score <= 2){ color='#ff5c78'; text='Weak'; }
    else if(score <= 4){ color='#ff8a3d'; text='Medium'; }
    else { color='#12d9a4'; text='Strong'; }
    bar.style.width = pct + '%';
    bar.style.background = color;
    label.textContent = 'Strength: ' + text;
  }

  function refresh(){
    var len = parseInt(lenInput.value, 10);
    lenVal.textContent = len;
    var pw = generatePassword(len);
    if(!pw){
      output.textContent = 'Select at least one character type';
      bar.style.width = '0%';
      label.textContent = 'Strength: —';
      return;
    }
    output.textContent = pw;
    updateStrength(pw);
  }

  lenInput.addEventListener('input', refresh);
  ['pw-upper','pw-lower','pw-numbers','pw-symbols','pw-exclude-ambiguous'].forEach(function(id){
    document.getElementById(id).addEventListener('change', refresh);
  });
  document.getElementById('pw-generate').addEventListener('click', refresh);
  document.getElementById('pw-copy').addEventListener('click', function(){
    window.NT.copyText(output.textContent, 'Password copied!');
  });

  document.getElementById('pw-generate-many').addEventListener('click', function(){
    var count = Math.max(1, Math.min(50, parseInt(document.getElementById('pw-count').value,10) || 5));
    var len = parseInt(lenInput.value, 10);
    var list = [];
    for(var i=0;i<count;i++){ list.push(generatePassword(len)); }
    var box = document.getElementById('pw-list-output');
    box.style.display = 'block';
    box.textContent = list.join('\n');
  });

  refresh();
})();
