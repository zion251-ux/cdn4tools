(function(){
  "use strict";
  var input = document.getElementById('dlr-input');
  var output = document.getElementById('dlr-output');
  var status = document.getElementById('dlr-status');

  function process(){
    var keep = document.getElementById('dlr-keep').value;
    var trim = document.getElementById('dlr-trim').checked;
    var caseInsensitive = document.getElementById('dlr-case').checked;
    var lines = input.value.split('\n');

    function normalize(line){
      var l = trim ? line.trim() : line;
      return caseInsensitive ? l.toLowerCase() : l;
    }

    var seen = {};
    var result = [];

    if(keep === 'first'){
      lines.forEach(function(line){
        var key = normalize(line);
        if(!seen[key]){ seen[key] = true; result.push(line); }
      });
    } else {
      var reversed = lines.slice().reverse();
      var resultRev = [];
      reversed.forEach(function(line){
        var key = normalize(line);
        if(!seen[key]){ seen[key] = true; resultRev.push(line); }
      });
      result = resultRev.reverse();
    }

    output.value = result.join('\n');
    var removed = lines.length - result.length;
    status.textContent = removed > 0 ? '✓ Removed ' + removed + ' duplicate line(s) — ' + result.length + ' unique lines remain.' : 'No duplicates found.';
    status.style.color = removed > 0 ? 'var(--accent-ink)' : 'var(--text-dim)';
  }

  document.getElementById('dlr-process').addEventListener('click', process);
  document.getElementById('dlr-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Process text first'); return; }
    window.NT.copyText(output.value, 'Result copied!');
  });

  process();
})();
