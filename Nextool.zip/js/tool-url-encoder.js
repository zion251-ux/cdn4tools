(function(){
  "use strict";
  var input = document.getElementById('url-input');
  var output = document.getElementById('url-output');
  var component = document.getElementById('url-component');

  document.getElementById('url-encode').addEventListener('click', function(){
    try{
      output.value = component.checked ? encodeURIComponent(input.value) : encodeURI(input.value);
    }catch(e){ window.NT.toast('Could not encode input'); }
  });

  document.getElementById('url-decode').addEventListener('click', function(){
    try{
      output.value = component.checked ? decodeURIComponent(input.value) : decodeURI(input.value);
    }catch(e){ window.NT.toast('Invalid encoded string'); }
  });

  document.getElementById('url-swap').addEventListener('click', function(){
    var tmp = input.value; input.value = output.value; output.value = tmp;
  });

  document.getElementById('url-clear').addEventListener('click', function(){
    input.value=''; output.value='';
  });

  document.getElementById('url-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to copy yet'); return; }
    window.NT.copyText(output.value, 'Copied to clipboard!');
  });
})();
