(function(){
  "use strict";
  var WORDS = ("lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum").split(' ');

  function randWord(){ return WORDS[Math.floor(Math.random()*WORDS.length)]; }

  function makeSentence(minW, maxW){
    var len = minW + Math.floor(Math.random()*(maxW-minW));
    var arr = [];
    for(var i=0;i<len;i++) arr.push(randWord());
    var sentence = arr.join(' ');
    return sentence.charAt(0).toUpperCase() + sentence.slice(1) + '.';
  }

  function makeParagraph(sentCount){
    var arr = [];
    for(var i=0;i<sentCount;i++) arr.push(makeSentence(6,16));
    return arr.join(' ');
  }

  function generate(){
    var type = document.getElementById('li-type').value;
    var count = Math.max(1, Math.min(100, parseInt(document.getElementById('li-count').value,10) || 1));
    var startClassic = document.getElementById('li-start').value === 'yes';
    var result = '';

    if(type === 'words'){
      var arr = [];
      for(var i=0;i<count;i++) arr.push(randWord());
      if(startClassic){ arr = ['lorem','ipsum','dolor','sit','amet'].concat(arr).slice(0,count); }
      result = arr.join(' ');
      result = result.charAt(0).toUpperCase() + result.slice(1) + '.';
    } else if(type === 'sentences'){
      var sarr = [];
      for(var j=0;j<count;j++) sarr.push(makeSentence(6,16));
      if(startClassic) sarr[0] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.';
      result = sarr.join(' ');
    } else {
      var parr = [];
      for(var k=0;k<count;k++) parr.push(makeParagraph(4 + Math.floor(Math.random()*3)));
      if(startClassic) parr[0] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. ' + parr[0];
      result = parr.join('\n\n');
    }
    document.getElementById('li-output').value = result;
  }

  document.getElementById('li-generate').addEventListener('click', generate);
  document.getElementById('li-copy').addEventListener('click', function(){
    var val = document.getElementById('li-output').value;
    if(!val){ window.NT.toast('Generate text first'); return; }
    window.NT.copyText(val, 'Copied to clipboard!');
  });

  generate();
})();
