(function(){
  "use strict";
  var chips = document.querySelectorAll('[data-unit]');
  var metricFields = document.getElementById('bmi-metric-fields');
  var imperialFields = document.getElementById('bmi-imperial-fields');
  var currentUnit = 'metric';

  chips.forEach(function(chip){
    chip.addEventListener('click', function(){
      chips.forEach(function(c){ c.classList.remove('active'); });
      chip.classList.add('active');
      currentUnit = chip.getAttribute('data-unit');
      metricFields.style.display = currentUnit === 'metric' ? '' : 'none';
      imperialFields.style.display = currentUnit === 'imperial' ? '' : 'none';
      calculate();
    });
  });

  function getCategory(bmi){
    if(bmi < 18.5) return { label: 'Underweight', pct: (bmi/18.5)*25, color:'#5b8def' };
    if(bmi < 25) return { label: 'Normal weight', pct: 25 + ((bmi-18.5)/(25-18.5))*25, color:'#12d9a4' };
    if(bmi < 30) return { label: 'Overweight', pct: 50 + ((bmi-25)/(30-25))*25, color:'#ff8a3d' };
    return { label: 'Obese', pct: Math.min(100, 75 + ((bmi-30)/10)*25), color:'#ff5c78' };
  }

  function calculate(){
    var bmi;
    if(currentUnit === 'metric'){
      var kg = parseFloat(document.getElementById('bmi-weight-kg').value);
      var cm = parseFloat(document.getElementById('bmi-height-cm').value);
      if(!kg || !cm){ window.NT.toast('Enter valid weight and height'); return; }
      var m = cm/100;
      bmi = kg / (m*m);
    } else {
      var lb = parseFloat(document.getElementById('bmi-weight-lb').value);
      var inch = parseFloat(document.getElementById('bmi-height-in').value);
      if(!lb || !inch){ window.NT.toast('Enter valid weight and height'); return; }
      bmi = (lb / (inch*inch)) * 703;
    }
    var cat = getCategory(bmi);
    document.getElementById('bmi-value').textContent = bmi.toFixed(1);
    document.getElementById('bmi-category').textContent = cat.label;
    document.getElementById('bmi-category').style.color = cat.color;
    var bar = document.getElementById('bmi-gauge-bar');
    bar.style.width = Math.min(100, cat.pct) + '%';
    bar.style.background = cat.color;
  }

  document.getElementById('bmi-calculate').addEventListener('click', calculate);
  document.querySelectorAll('#bmi-metric-fields input, #bmi-imperial-fields input').forEach(function(inp){
    inp.addEventListener('input', calculate);
  });

  calculate();
})();
