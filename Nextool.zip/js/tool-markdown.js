(function(){
  "use strict";
  var input = document.getElementById('md-input');
  var preview = document.getElementById('md-preview');
  var htmlOutput = document.getElementById('md-html-output');

  function escapeHtml(str){
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  function inlineFormat(text){
    text = escapeHtml(text);
    text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
    text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/_([^_]+)_/g, '<em>$1</em>');
    text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    return text;
  }

  function mdToHtml(md){
    var lines = md.split('\n');
    var html = [];
    var inList = false;
    lines.forEach(function(line){
      var headingMatch = line.match(/^(#{1,6})\s+(.*)$/);
      var listMatch = line.match(/^[-*]\s+(.*)$/);
      if(headingMatch){
        if(inList){ html.push('</ul>'); inList = false; }
        var level = headingMatch[1].length;
        html.push('<h' + level + '>' + inlineFormat(headingMatch[2]) + '</h' + level + '>');
      } else if(listMatch){
        if(!inList){ html.push('<ul>'); inList = true; }
        html.push('<li>' + inlineFormat(listMatch[1]) + '</li>');
      } else if(line.trim() === ''){
        if(inList){ html.push('</ul>'); inList = false; }
      } else {
        if(inList){ html.push('</ul>'); inList = false; }
        html.push('<p>' + inlineFormat(line) + '</p>');
      }
    });
    if(inList) html.push('</ul>');
    return html.join('\n');
  }

  function render(){
    var html = mdToHtml(input.value);
    preview.innerHTML = html;
    htmlOutput.value = html;
  }

  input.addEventListener('input', render);

  document.getElementById('md-copy-html').addEventListener('click', function(){
    if(!htmlOutput.value){ window.NT.toast('Write some Markdown first'); return; }
    window.NT.copyText(htmlOutput.value, 'HTML copied!');
  });

  document.getElementById('md-view-html-toggle').addEventListener('click', function(){
    var wrap = document.getElementById('md-html-wrap');
    wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
  });

  render();
})();
