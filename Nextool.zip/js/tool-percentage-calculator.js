(function(){
  "use strict";
  var chips = document.querySelectorAll('[data-mode]');
  var modes = { of: document.getElementById('pc-mode-of'), 'is-what': document.getElementById('pc-mode-is-what'), change: document.getElementById('pc-mode-change') };
  var resultText = document.getElementById('pc-result-text');
  var banner = document.getElementById('pc-result-banner');
  var currentMode = 'of';

  function calc(){
    if(currentMode === 'of'){
      var x = parseFloat(document.getElementById('pc-of-x').value) || 0;
      var y = parseFloat(document.getElementById('pc-of-y').value) || 0;
      var result = (x/100) * y;
      resultText.textContent = x + '% of ' + y + ' = ' + round(result);
      banner.className = 'result-banner';
    } else if(currentMode === 'is-what'){
      var xi = parseFloat(document.getElementById('pc-iw-x').value) || 0;
      var yi = parseFloat(document.getElementById('pc-iw-y').value) || 0;
      var pct = yi !== 0 ? (xi/yi)*100 : 0;
      resultText.textContent = xi + ' is ' + round(pct) + '% of ' + yi;
      banner.className = 'result-banner';
    } else {
      var xc = parseFloat(document.getElementById('pc-ch-x').value) || 0;
      var yc = parseFloat(document.getElementById('pc-ch-y').value) || 0;
      var change = xc !== 0 ? ((yc-xc)/xc)*100 : 0;
      var dir = change >= 0 ? 'increase' : 'decrease';
      resultText.textContent = round(Math.abs(change)) + '% ' + dir + ' from ' + xc + ' to ' + yc;
      banner.className = 'result-banner ' + (change >= 0 ? '' : 'warn');
    }
  }

  function round(n){ return Math.round(n * 100) / 100; }

  chips.forEach(function(chip){
    chip.addEventListener('click', function(){
      chips.forEach(function(c){ c.classList.remove('active'); });
      chip.classList.add('active');
      currentMode = chip.getAttribute('data-mode');
      Object.keys(modes).forEach(function(m){ modes[m].style.display = (m === currentMode) ? '' : 'none'; });
      calc();
    });
  });

  document.querySelectorAll('#pc-mode-of input, #pc-mode-is-what input, #pc-mode-change input').forEach(function(inp){
    inp.addEventListener('input', calc);
  });

  calc();
})();
