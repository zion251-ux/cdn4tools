(function(){
  "use strict";
  var textInput = document.getElementById('qr-text');
  var sizeSelect = document.getElementById('qr-size');
  var colorInput = document.getElementById('qr-color');
  var img = document.getElementById('qr-image');
  var generateBtn = document.getElementById('qr-generate');
  var downloadBtn = document.getElementById('qr-download');

  function hexToRgbTriplet(hex){
    hex = hex.replace('#','');
    if(hex.length === 3) hex = hex.split('').map(function(c){return c+c;}).join('');
    return hex;
  }

  function buildUrl(text, size, colorHex){
    var data = encodeURIComponent(text);
    var fg = hexToRgbTriplet(colorHex);
    // api.qrserver.com — free, no-auth, CORS-enabled QR image endpoint.
    return 'https://api.qrserver.com/v1/create-qr-code/?size=' + size + 'x' + size +
           '&data=' + data + '&color=' + fg + '&bgcolor=ffffff&margin=8';
  }

  function render(){
    var text = textInput.value.trim() || 'https://nextools.example.com';
    var size = parseInt(sizeSelect.value, 10);
    var color = colorInput.value;
    var url = buildUrl(text, size, color);
    img.width = size;
    img.height = size;
    img.src = url;
  }

  img.addEventListener('error', function(){
    if(window.NT) window.NT.toast('Could not load QR code — check your connection');
  });

  generateBtn.addEventListener('click', render);
  textInput.addEventListener('keyup', function(e){ if(e.key === 'Enter' && e.ctrlKey) render(); });
  sizeSelect.addEventListener('change', render);
  colorInput.addEventListener('input', render);

  downloadBtn.addEventListener('click', function(){
    if(!img.src){ window.NT.toast('Generate a QR code first'); return; }
    var a = document.createElement('a');
    a.href = img.src; a.download = 'qrcode.png'; a.target = '_blank';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    window.NT.toast('Opening QR code for download');
  });

  render();
})();
