(function(){
  "use strict";
  var input = document.getElementById('pal-input');
  var banner = document.getElementById('pal-result-banner');
  var resultText = document.getElementById('pal-result-text');
  var comparison = document.getElementById('pal-comparison');

  function check(){
    var raw = input.value;
    if(!raw.trim()){ resultText.textContent = 'Enter something to check'; banner.className='result-banner'; comparison.textContent=''; return; }

    var ignoreSpaces = document.getElementById('pal-ignore-spaces').checked;
    var ignoreCase = document.getElementById('pal-ignore-case').checked;

    var cleaned = raw;
    if(ignoreSpaces) cleaned = cleaned.replace(/[^a-zA-Z0-9]/g, '');
    if(ignoreCase) cleaned = cleaned.toLowerCase();

    var reversed = cleaned.split('').reverse().join('');
    var isPalindrome = cleaned === reversed && cleaned.length > 0;

    resultText.textContent = isPalindrome ? '✓ Yes, this is a palindrome!' : '✗ No, this is not a palindrome.';
    banner.className = 'result-banner ' + (isPalindrome ? '' : 'bad');
    comparison.textContent = 'Cleaned:  ' + cleaned + '\nReversed: ' + reversed;
  }

  input.addEventListener('input', check);
  document.getElementById('pal-ignore-spaces').addEventListener('change', check);
  document.getElementById('pal-ignore-case').addEventListener('change', check);
  document.getElementById('pal-check').addEventListener('click', check);

  check();
})();
