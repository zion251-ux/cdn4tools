(function(){
  "use strict";
  var input = document.getElementById('ts-input');
  var output = document.getElementById('ts-output');
  var dedupe = document.getElementById('ts-dedupe');

  function shuffleArr(arr){
    for(var i=arr.length-1;i>0;i--){
      var j = Math.floor(Math.random()*(i+1));
      var tmp = arr[i]; arr[i]=arr[j]; arr[j]=tmp;
    }
    return arr;
  }

  function applyDedupe(lines){
    if(!dedupe.checked) return lines;
    var seen = {};
    return lines.filter(function(l){
      if(seen[l]) return false;
      seen[l] = true;
      return true;
    });
  }

  document.querySelectorAll('[data-sort]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var lines = applyDedupe(input.value.split('\n'));
      var type = btn.getAttribute('data-sort');
      switch(type){
        case 'asc': lines.sort(function(a,b){ return a.localeCompare(b); }); break;
        case 'desc': lines.sort(function(a,b){ return b.localeCompare(a); }); break;
        case 'length-asc': lines.sort(function(a,b){ return a.length - b.length; }); break;
        case 'length-desc': lines.sort(function(a,b){ return b.length - a.length; }); break;
        case 'reverse': lines.reverse(); break;
        case 'shuffle': shuffleArr(lines); break;
      }
      output.value = lines.join('\n');
    });
  });

  document.getElementById('ts-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Sort text first'); return; }
    window.NT.copyText(output.value, 'Result copied!');
  });
})();
