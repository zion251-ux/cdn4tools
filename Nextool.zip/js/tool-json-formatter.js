(function(){
  "use strict";
  var input = document.getElementById('json-input');
  var output = document.getElementById('json-output');
  var status = document.getElementById('json-status');

  function setStatus(msg, ok){
    status.textContent = msg;
    status.style.color = ok ? 'var(--accent-ink)' : 'var(--danger)';
  }

  function parseSafe(){
    var raw = input.value.trim();
    if(!raw){ setStatus('Enter some JSON to get started.', true); return null; }
    try{
      return JSON.parse(raw);
    }catch(e){
      setStatus('Invalid JSON: ' + e.message, false);
      output.value = '';
      return undefined; // undefined signals error already handled
    }
  }

  document.getElementById('json-format').addEventListener('click', function(){
    var val = parseSafe();
    if(val === undefined) return;
    if(val === null){ output.value=''; return; }
    output.value = JSON.stringify(val, null, 2);
    setStatus('✓ Valid JSON — formatted with 2-space indentation.', true);
  });

  document.getElementById('json-minify').addEventListener('click', function(){
    var val = parseSafe();
    if(val === undefined) return;
    if(val === null){ output.value=''; return; }
    output.value = JSON.stringify(val);
    setStatus('✓ Valid JSON — minified.', true);
  });

  document.getElementById('json-validate').addEventListener('click', function(){
    var val = parseSafe();
    if(val === undefined) return;
    if(val === null) return;
    setStatus('✓ Valid JSON.', true);
  });

  document.getElementById('json-sample').addEventListener('click', function(){
    input.value = JSON.stringify({
      name: "NexTools",
      version: 1.0,
      isFree: true,
      categories: ["developer","text","convert","calculator","utility"],
      stats: { tools: 25, users: null }
    }, null, 2);
    setStatus('Sample loaded — click Format or Validate.', true);
  });

  document.getElementById('json-clear').addEventListener('click', function(){
    input.value = ''; output.value = ''; setStatus('', true);
  });

  document.getElementById('json-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to copy yet'); return; }
    window.NT.copyText(output.value, 'Output copied!');
  });

  document.getElementById('json-download').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to download yet'); return; }
    window.NT.downloadText('data.json', output.value, 'application/json');
  });
})();
