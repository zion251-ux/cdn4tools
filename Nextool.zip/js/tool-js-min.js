(function(){
  "use strict";
  var input = document.getElementById('js-input');
  var output = document.getElementById('js-output');
  var status = document.getElementById('js-status');

  // Tokenize into strings/comments/code so we don't corrupt string contents.
  function tokenize(code){
    var tokens = [];
    var i = 0, len = code.length;
    while(i < len){
      var ch = code[i];
      if(ch === '"' || ch === "'" || ch === '`'){
        var quote = ch; var start = i; i++;
        while(i < len && code[i] !== quote){
          if(code[i] === '\\') i++;
          i++;
        }
        i++;
        tokens.push({type:'string', value: code.slice(start, i)});
      } else if(ch === '/' && code[i+1] === '/'){
        var start2 = i;
        while(i < len && code[i] !== '\n') i++;
        tokens.push({type:'linecomment', value: code.slice(start2, i)});
      } else if(ch === '/' && code[i+1] === '*'){
        var start3 = i; i += 2;
        while(i < len && !(code[i] === '*' && code[i+1] === '/')) i++;
        i += 2;
        tokens.push({type:'blockcomment', value: code.slice(start3, i)});
      } else {
        var start4 = i;
        while(i < len && code[i] !== '"' && code[i] !== "'" && code[i] !== '`' &&
              !(code[i] === '/' && (code[i+1] === '/' || code[i+1] === '*'))){
          i++;
        }
        tokens.push({type:'code', value: code.slice(start4, i)});
      }
    }
    return tokens;
  }

  function minify(code){
    var tokens = tokenize(code);
    var out = '';
    tokens.forEach(function(t){
      if(t.type === 'string'){ out += t.value; }
      else if(t.type === 'linecomment' || t.type === 'blockcomment'){ /* drop */ }
      else {
        var c = t.value.replace(/\s+/g, ' ');
        c = c.replace(/\s*([{}();,:=+\-*/%<>!&|?])\s*/g, '$1');
        out += c;
      }
    });
    return out.replace(/;}/g, '}').trim();
  }

  function beautify(code){
    var tokens = tokenize(code);
    // Reassemble preserving strings, drop comments, then indent by braces.
    var plain = '';
    tokens.forEach(function(t){
      if(t.type === 'string') plain += t.value;
      else if(t.type === 'code') plain += t.value;
      // drop comments for clean beautify
    });
    plain = plain.replace(/\s+/g, ' ').trim();
    var result = ''; var indent = 0;
    for(var i=0;i<plain.length;i++){
      var ch = plain[i];
      if(ch === '{'){ result = result.trimEnd() + ' {\n'; indent++; result += '  '.repeat(indent); }
      else if(ch === '}'){ indent = Math.max(0,indent-1); result = result.trimEnd() + '\n' + '  '.repeat(indent) + '}\n' + '  '.repeat(indent); }
      else if(ch === ';'){ result += ';\n' + '  '.repeat(indent); }
      else { result += ch; }
    }
    return result.split('\n').map(function(l){return l.trimEnd();})
      .filter(function(l,idx,arr){ return !(l.trim()==='' && arr[idx-1] && arr[idx-1].trim()===''); })
      .join('\n').trim();
  }

  document.getElementById('js-minify').addEventListener('click', function(){
    if(!input.value.trim()){ status.textContent = 'Paste some JavaScript first.'; return; }
    try{
      output.value = minify(input.value);
      status.textContent = '✓ Minified — ' + input.value.length + ' → ' + output.value.length + ' characters.';
    }catch(e){ status.textContent = 'Could not minify: ' + e.message; }
  });

  document.getElementById('js-beautify').addEventListener('click', function(){
    if(!input.value.trim()){ status.textContent = 'Paste some JavaScript first.'; return; }
    try{
      output.value = beautify(input.value);
      status.textContent = '✓ Beautified.';
    }catch(e){ status.textContent = 'Could not beautify: ' + e.message; }
  });

  document.getElementById('js-clear').addEventListener('click', function(){
    input.value=''; output.value=''; status.textContent='';
  });

  document.getElementById('js-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Nothing to copy yet'); return; }
    window.NT.copyText(output.value, 'Copied to clipboard!');
  });
})();
