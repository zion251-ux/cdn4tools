(function(){
  "use strict";

  var UNITS = {
    length: {
      base: 'meter',
      units: {
        meter: 1, kilometer: 1000, centimeter: 0.01, millimeter: 0.001,
        mile: 1609.344, yard: 0.9144, foot: 0.3048, inch: 0.0254, 'nautical mile': 1852
      }
    },
    weight: {
      base: 'kilogram',
      units: {
        kilogram: 1, gram: 0.001, milligram: 0.000001, 'metric ton': 1000,
        pound: 0.45359237, ounce: 0.028349523125, stone: 6.35029318
      }
    },
    area: {
      base: 'square meter',
      units: {
        'square meter': 1, 'square kilometer': 1e6, 'square centimeter': 0.0001,
        hectare: 10000, acre: 4046.8564224, 'square mile': 2589988.110336,
        'square foot': 0.09290304, 'square yard': 0.83612736
      }
    },
    volume: {
      base: 'liter',
      units: {
        liter: 1, milliliter: 0.001, 'cubic meter': 1000,
        gallon: 3.785411784, quart: 0.946352946, pint: 0.473176473,
        cup: 0.2365882365, 'fluid ounce': 0.0295735295625
      }
    },
    data: {
      base: 'byte',
      units: {
        byte: 1, kilobyte: 1024, megabyte: 1024*1024, gigabyte: 1024*1024*1024,
        terabyte: 1024*1024*1024*1024, bit: 0.125
      }
    }
  };

  var fromValue = document.getElementById('uc-from-value');
  var toValue = document.getElementById('uc-to-value');
  var fromUnit = document.getElementById('uc-from-unit');
  var toUnit = document.getElementById('uc-to-unit');
  var resultText = document.getElementById('uc-result-text');
  var chips = document.querySelectorAll('[data-category]');
  var currentCategory = 'length';

  function populateUnits(category){
    var isTemp = category === 'temperature';
    fromUnit.innerHTML = '';
    toUnit.innerHTML = '';
    var unitNames = isTemp ? ['celsius','fahrenheit','kelvin'] : Object.keys(UNITS[category].units);
    unitNames.forEach(function(name){
      var opt1 = document.createElement('option'); opt1.value = name; opt1.textContent = capitalize(name);
      var opt2 = document.createElement('option'); opt2.value = name; opt2.textContent = capitalize(name);
      fromUnit.appendChild(opt1);
      toUnit.appendChild(opt2.cloneNode(true));
    });
    if(unitNames.length > 1) toUnit.selectedIndex = 1;
  }

  function capitalize(s){ return s.charAt(0).toUpperCase() + s.slice(1); }

  function convertTemp(value, from, to){
    var celsius;
    if(from === 'celsius') celsius = value;
    else if(from === 'fahrenheit') celsius = (value - 32) * 5/9;
    else celsius = value - 273.15;

    if(to === 'celsius') return celsius;
    if(to === 'fahrenheit') return celsius * 9/5 + 32;
    return celsius + 273.15;
  }

  function convert(){
    var val = parseFloat(fromValue.value);
    if(isNaN(val)){ toValue.value = ''; resultText.textContent = 'Enter a valid number'; return; }
    var from = fromUnit.value, to = toUnit.value;
    var result;
    if(currentCategory === 'temperature'){
      result = convertTemp(val, from, to);
    } else {
      var unitDefs = UNITS[currentCategory].units;
      var baseValue = val * unitDefs[from];
      result = baseValue / unitDefs[to];
    }
    var rounded = Math.abs(result) < 0.0001 && result !== 0 ? result.toExponential(4) : parseFloat(result.toFixed(6));
    toValue.value = rounded;
    resultText.textContent = val + ' ' + from + ' = ' + rounded + ' ' + to;
  }

  chips.forEach(function(chip){
    chip.addEventListener('click', function(){
      chips.forEach(function(c){ c.classList.remove('active'); });
      chip.classList.add('active');
      currentCategory = chip.getAttribute('data-category');
      populateUnits(currentCategory);
      convert();
    });
  });

  fromValue.addEventListener('input', convert);
  fromUnit.addEventListener('change', convert);
  toUnit.addEventListener('change', convert);

  document.getElementById('uc-swap').addEventListener('click', function(){
    var tmp = fromUnit.value;
    fromUnit.value = toUnit.value;
    toUnit.value = tmp;
    convert();
  });

  populateUnits(currentCategory);
  convert();
})();
