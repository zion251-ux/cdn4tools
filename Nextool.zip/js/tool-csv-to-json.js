(function(){
  "use strict";
  var input = document.getElementById('csv-input');
  var output = document.getElementById('csv-output');
  var status = document.getElementById('csv-status');
  var headersCheck = document.getElementById('csv-headers');

  function parseCSVLine(line){
    var result = [];
    var current = '';
    var inQuotes = false;
    for(var i=0;i<line.length;i++){
      var ch = line[i];
      if(inQuotes){
        if(ch === '"'){
          if(line[i+1] === '"'){ current += '"'; i++; }
          else inQuotes = false;
        } else current += ch;
      } else {
        if(ch === '"') inQuotes = true;
        else if(ch === ','){ result.push(current); current = ''; }
        else current += ch;
      }
    }
    result.push(current);
    return result;
  }

  function csvToJson(csv, hasHeaders){
    var lines = csv.split(/\r?\n/).filter(function(l){ return l.trim() !== ''; });
    if(!lines.length) return [];
    var rows = lines.map(parseCSVLine);
    if(hasHeaders){
      var headers = rows[0];
      return rows.slice(1).map(function(row){
        var obj = {};
        headers.forEach(function(h, idx){ obj[h.trim()] = (row[idx] !== undefined ? row[idx].trim() : ''); });
        return obj;
      });
    } else {
      return rows.map(function(row){ return row.map(function(c){ return c.trim(); }); });
    }
  }

  function convert(){
    if(!input.value.trim()){ status.textContent = 'Paste CSV data or upload a file first.'; return; }
    try{
      var result = csvToJson(input.value, headersCheck.checked);
      output.value = JSON.stringify(result, null, 2);
      status.textContent = '✓ Converted ' + result.length + ' row(s) to JSON.';
      status.style.color = 'var(--accent-ink)';
    }catch(e){
      status.textContent = 'Error parsing CSV: ' + e.message;
      status.style.color = 'var(--danger)';
    }
  }

  document.getElementById('csv-convert').addEventListener('click', convert);

  document.getElementById('csv-sample').addEventListener('click', function(){
    input.value = "name,age,city\nAlice,28,New York\nBob,34,San Francisco\nCharlie,22,Chicago";
    convert();
  });

  document.getElementById('csv-file-input').addEventListener('change', function(e){
    var file = e.target.files[0];
    if(!file) return;
    var reader = new FileReader();
    reader.onload = function(ev){
      input.value = ev.target.result;
      convert();
    };
    reader.readAsText(file);
  });

  document.getElementById('csv-copy').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Convert some CSV first'); return; }
    window.NT.copyText(output.value, 'JSON copied!');
  });

  document.getElementById('csv-download').addEventListener('click', function(){
    if(!output.value){ window.NT.toast('Convert some CSV first'); return; }
    window.NT.downloadText('data.json', output.value, 'application/json');
  });
})();
